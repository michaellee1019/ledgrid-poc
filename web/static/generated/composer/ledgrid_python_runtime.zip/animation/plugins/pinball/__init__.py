#!/usr/bin/env python3
"""Fast, self-playing, arcade pinball animation for the physical LED grid."""

from __future__ import annotations

import math
import random
import threading
from collections import deque
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Dict, List, Mapping, Optional, Tuple

import numpy as np

from animation import AnimationBase, RenderedFrame
from animation.core.component_catalog import ComponentDescriptor
from animation.core.presentation_contracts import ResolvedScene
from animation.core.plant_awareness import InstallationGeometryContact, PlantModifierState
from animation.libraries.palette_field import AnimatedPaletteField


Color = Tuple[int, int, int]


@dataclass
class Burst:
    x: float
    y: float
    color: Color
    age: float = 0.0
    life: float = 0.55


class PinballAnimation(AnimationBase):
    """A CPU-light pinball show inspired by colorful 1990s PC tables."""

    ANIMATION_NAME = "Arcade Pinball"
    ANIMATION_DESCRIPTION = "Fast self-playing 90s PC pinball with scores, streaks, jackpots, and minigames"
    ANIMATION_AUTHOR = "LED Grid Team"
    ANIMATION_VERSION = "1.0"
    COMPONENT_ID, COMPONENT_VERSION, PROVIDER, ROLE = "pinball", 1, "python", "animation"
    FRAME_FORMAT, TIMING_POLICY, PALETTE_POLICY = "rgb_uint8_strip_major", "scaled_context", "semantic"
    CAPABILITIES = frozenset(("semantic_palette_roles", "scaled_context", "effect_intent", "simulation_inputs"))
    # The manager-owned bumper effect is the sole switch for this simulation
    # input.  Calibration never becomes an authored Pinball parameter.
    PLANT_MODIFIER_SUPPORT = frozenset(("bumper",))
    INSTALLATION_GEOMETRY_CONTACT = True
    INTERACTION_TYPES = frozenset(("primary",))
    COMPOSER_INTERACTIONS = {
        "point": {"kind": "primary", "label": "Flip and nudge local preview"},
    }
    MAX_PENDING_PRIMARY_EVENTS = 1
    MAX_PRIMARY_SPEED = 124.0
    PRIMARY_FLIPPER_KICK = 36.0
    PRIMARY_NUDGE_KICK = 16.0
    DEFAULTS = MappingProxyType({"table_tick_hz": 40.5, "render_fps": 100.0, "chaos": .72, "seed": 95})
    COMPONENT_DESCRIPTOR = ComponentDescriptor(
        component_id=COMPONENT_ID, version=COMPONENT_VERSION, provider=PROVIDER, role=ROLE,
        timing_policy=TIMING_POLICY, alpha_behavior="opaque", palette_policy=PALETTE_POLICY,
        plant_capabilities=("effect_intent", "simulation_inputs"), fidelity_exceptions=(),
        optional_simulation_inputs=("installation_geometry_contact",), defaults=DEFAULTS,
    )
    _PALETTE_TINTS = MappingProxyType({"neutral": (1.0, .82, .40), "mist": (.48, .82, 1.0),
                                       "spectrum": (1.0, .42, .94), "ember": (1.0, .45, .18)})

    NAVY = (0, 3, 18)
    BLUE = (0, 34, 92)
    CYAN = (0, 235, 255)
    WHITE = (255, 255, 245)
    YELLOW = (255, 226, 0)
    ORANGE = (255, 84, 0)
    RED = (255, 18, 44)
    MAGENTA = (255, 0, 190)
    GREEN = (20, 255, 80)

    def __init__(self, controller, config: Mapping[str, Any] | None = None):
        self._authored_config = dict(config or {})
        super().__init__(controller, self._authored_config)
        self.width, self.height = self.get_strip_info()
        self.default_params = dict(self.DEFAULTS)
        self.params = self._normalized_parameters(self._authored_config)
        self._presentation_context: ResolvedScene | None = None
        self.random = random.Random(int(self.params.get("seed", 95)))

        self._static = np.zeros((self.height, self.width, 3), dtype=np.uint8)
        self._canvas = np.zeros_like(self._static)
        # Installation geometry is copied only on a manager/preview context
        # refresh.  Canvas coordinates are image-style (y, x), while the shared
        # provider remains strip-major (x, y).
        self._globe_cores = np.zeros((self.height, self.width), dtype=bool)
        self._globe_clearance = np.zeros((self.height, self.width), dtype=bool)
        self._globe_geometry_identity: Optional[Tuple[Any, ...]] = None
        self._globe_bumper_strength = 0.0
        self._globe_contact_active = False
        self._globe_bumper_hits = 0
        hues = np.linspace(0.0, 1.0, 256, endpoint=False, dtype=np.float32)
        saturation = np.full(256, 0.94, dtype=np.float32)
        values = (0.10 + 0.20 * (np.sin(hues * math.tau * 3.0) * 0.5 + 0.5)).astype(np.float32)
        self._psy_palette = self.hsv_to_rgb_array(hues, saturation, values)
        self._background_field = AnimatedPaletteField(
            self.width, self.height, self._psy_palette
        )
        self._build_table()

        self.ball_x = self.width - 4.0
        self.ball_y = self.height - 18.0
        self.ball_vx = -7.0
        self.ball_vy = -76.0
        self.score = 95000
        self.display_score = float(self.score)
        self.streak = 0
        self.multiplier = 1
        self.balls = 3
        self.mode = "READY"
        self.mode_time = 0.0
        self.mode_count = 0
        self.drain_time = 0.0
        self.last_elapsed: Optional[float] = None
        self.last_render_elapsed: Optional[float] = None
        self.last_rendered_frame: Optional[np.ndarray] = None
        # Input is deliberately a one-slot transient queue. It never becomes
        # Scene state, and a pointer-event burst cannot create later catch-up.
        self._interaction_lock = threading.Lock()
        self._primary_events = deque(maxlen=self.MAX_PENDING_PRIMARY_EVENTS)
        self._primary_interactions_received = 0
        self._primary_interactions_applied = 0
        self._primary_flipper_flash = 0.0
        self.bursts: List[Burst] = []
        self.lamps = [False] * 5
        self._next_mode_at = 5.5
        self._event_cooldown = 0.0
        self._hit_flash = 0.0
        self._failure_flash = 0.0
        self._success_flash = 0.0
        self._sim_time = 0.0

    @classmethod
    def component_descriptor(cls) -> ComponentDescriptor:
        return cls.COMPONENT_DESCRIPTOR

    @classmethod
    def _normalized_parameters(cls, values: Mapping[str, Any]) -> Dict[str, Any]:
        supplied = dict(values)
        unknown = sorted(set(supplied) - set(cls.DEFAULTS))
        if unknown:
            raise ValueError(f"Pinball received non-local parameters: {', '.join(unknown)}")
        result = dict(cls.DEFAULTS)
        result.update(supplied)
        for name, low, high in (("table_tick_hz", 12.0, 90.0), ("render_fps", 24.0, 120.0), ("chaos", 0.0, 1.0)):
            value = result[name]
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not low <= float(value) <= high:
                raise ValueError(f"{name} must be a number from {low} to {high}")
            result[name] = float(value)
        if isinstance(result["seed"], bool) or not isinstance(result["seed"], int) or not 0 <= result["seed"] <= 9999:
            raise ValueError("seed must be an integer from 0 to 9999")
        return result

    def update_parameters(self, new_params: Mapping[str, Any]) -> None:
        candidate = self._normalized_parameters({**self.params, **dict(new_params)})
        if candidate == self.params:
            return
        if candidate["seed"] != self.params["seed"]:
            self.random.seed(int(candidate["seed"]))
        self.params = candidate
        self.last_render_elapsed = None

    def get_parameter_schema(self) -> Dict[str, Dict[str, Any]]:
        return {
            "table_tick_hz": {
                "type": "float", "min": 12.0, "max": 90.0, "default": 40.5,
                "description": "Table simulation ticks per second",
            },
            "render_fps": {
                "type": "float", "min": 24.0, "max": 120.0, "default": 100.0,
                "description": "Maximum simulation and render rate",
            },
            "chaos": {
                "type": "float", "min": 0.0, "max": 1.0, "default": 0.72,
                "description": "Frequency of sparks, callouts, and surprise shots",
            },
            "seed": {
                "type": "int", "min": 0, "max": 9999, "default": 95,
                "description": "Repeatable table action seed",
            },
        }

    def on_presentation_context_changed(self, old: ResolvedScene | None, new: ResolvedScene) -> None:
        if new.descriptor.component_id != self.COMPONENT_ID or new.palette is None or not isinstance(new.palette.get("palette_id"), str):
            raise ValueError("Pinball requires a semantic Scene v2 palette")
        if old is None or old.palette != new.palette:
            self.last_render_elapsed = None
        self._presentation_context = new
        self._install_globe_contact(new)

    def set_presentation_context(self, context: ResolvedScene) -> None:
        self.on_presentation_context_changed(self._presentation_context, context)

    def render_resolved_scene(self, context: ResolvedScene) -> RenderedFrame:
        self.set_presentation_context(context)
        self.update_parameters(context.parameters)
        return self.generate_frame(context.phase_time, self.frame_count)

    def _install_globe_contact(self, context: ResolvedScene) -> None:
        """Refresh derived contact/planning views without touching game state."""
        effects = context.canonical_scene.get("plants", {}).get("effects", {})
        state = PlantModifierState.from_payload(effects)
        strength = state.strength("bumper", self.PLANT_MODIFIER_SUPPORT)
        contact = context.installation_geometry
        identity: Optional[Tuple[Any, ...]] = None
        if isinstance(contact, InstallationGeometryContact):
            identity = (contact.identity, contact.available, contact.status)
        effective_strength = (
            strength
            if isinstance(contact, InstallationGeometryContact) and contact.available
            else 0.0
        )
        refreshed = (
            identity != self._globe_geometry_identity
            or effective_strength != self._globe_bumper_strength
        )
        if identity != self._globe_geometry_identity:
            self._globe_cores.fill(False)
            self._globe_clearance.fill(False)
            if (
                isinstance(contact, InstallationGeometryContact)
                and contact.available
                and contact.exact_globe_cores.shape == (self.width, self.height)
                and contact.clearance.shape == (self.width, self.height)
            ):
                self._globe_cores[:] = contact.exact_globe_cores.T[::-1]
                self._globe_clearance[:] = contact.clearance.T[::-1]
            self._globe_geometry_identity = identity
        # A live effect/geometry change must not move the ball, consume RNG, or
        # fabricate a hit.  It only selects the already-derived next-tick rule.
        self._globe_bumper_strength = effective_strength
        if refreshed:
            self.last_render_elapsed = None

    def _apply_scene_palette(self, frame: np.ndarray) -> None:
        if self._presentation_context is None:
            return
        tint = np.asarray(self._PALETTE_TINTS.get(self._presentation_context.palette["palette_id"], self._PALETTE_TINTS["neutral"]), dtype=np.float32)
        source = frame.astype(np.float32)
        light = source.max(axis=1, keepdims=True) / 255.0
        np.clip(source * .56 + light * tint * 112.0, 0, 255, out=source)
        frame[:] = source.astype(np.uint8)

    def handle_interaction(
        self, kind: str, x: float, y: float, strength: float = 1.0,
    ) -> bool:
        """Queue one bounded flipper/nudge input for the next simulation tick."""
        values = (x, y, strength)
        if (
            kind != "primary"
            or any(
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(float(value))
                for value in values
            )
        ):
            return False
        x_value, y_value, strength_value = map(float, values)
        if (
            not 0.0 <= x_value < self.width
            or not 0.0 <= y_value < self.height
            or not 0.0 < strength_value <= 1.0
        ):
            return False
        with self._interaction_lock:
            self._primary_events.append((x_value, y_value, strength_value))
            self._primary_interactions_received += 1
        # The input needs a fresh presentation, but it does not advance
        # simulation time. _update consumes the event at the next source tick.
        self.last_render_elapsed = None
        return True

    def _drain_primary_interaction(self) -> None:
        with self._interaction_lock:
            event = self._primary_events.pop() if self._primary_events else None
            self._primary_events.clear()
        if event is None:
            return
        x, _y, strength = event
        center = (self.width - 1) * 0.5
        horizontal = (x - center) / max(1.0, center)
        self.ball_vx += horizontal * self.PRIMARY_NUDGE_KICK * strength
        self.ball_vy -= self.PRIMARY_FLIPPER_KICK * strength
        speed = math.hypot(self.ball_vx, self.ball_vy)
        if speed > self.MAX_PRIMARY_SPEED:
            scale = self.MAX_PRIMARY_SPEED / speed
            self.ball_vx *= scale
            self.ball_vy *= scale
        self._primary_flipper_flash = 0.16
        self._primary_interactions_applied += 1

    # Drawing helpers operate in logical top-to-bottom table coordinates.
    def _pixel(self, image: np.ndarray, x: int, y: int, color: Color, additive: bool = False):
        if 0 <= x < self.width and 0 <= y < self.height:
            if additive:
                image[y, x] = np.maximum(image[y, x], color)
            else:
                image[y, x] = color

    def _line(self, image: np.ndarray, x0: int, y0: int, x1: int, y1: int, color: Color):
        dx, dy = abs(x1 - x0), -abs(y1 - y0)
        sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
        error = dx + dy
        while True:
            self._pixel(image, x0, y0, color)
            if x0 == x1 and y0 == y1:
                return
            twice = 2 * error
            if twice >= dy:
                error += dy
                x0 += sx
            if twice <= dx:
                error += dx
                y0 += sy

    def _circle(self, image: np.ndarray, cx: int, cy: int, radius: int, color: Color, fill: bool = False):
        radius = max(0, radius)
        for yy in range(-radius, radius + 1):
            for xx in range(-radius, radius + 1):
                distance = xx * xx + yy * yy
                if distance <= radius * radius and (fill or distance >= (radius - 1) ** 2):
                    self._pixel(image, cx + xx, cy + yy, color)

    def _soft_dot(self, image: np.ndarray, x: float, y: float, color: Color, radius: float = 1.8):
        """Draw a subpixel-positioned radial glow with a brilliant core."""
        left, right = math.floor(x - radius), math.ceil(x + radius)
        top, bottom = math.floor(y - radius), math.ceil(y + radius)
        inv_radius = 1.0 / max(0.1, radius)
        for py in range(top, bottom + 1):
            for px in range(left, right + 1):
                distance = math.hypot(px - x, py - y) * inv_radius
                if distance >= 1.0:
                    continue
                weight = (1.0 - distance) ** 0.65
                shaded = tuple(min(255, int(channel * weight)) for channel in color)
                self._pixel(image, px, py, shaded, True)

    def _build_table(self):
        table = self._static
        table[:] = self.NAVY
        if self.width < 6 or self.height < 20:
            return

        # Subtle vertical PC-blue playfield bands.
        table[:, 1:-1:4] = (0, 7, 28)
        top = max(12, min(18, self.height // 7))
        bottom = self.height - 5
        left, right = 1, self.width - 2
        self._line(table, left, top, left, bottom - 9, self.CYAN)
        self._line(table, right, top, right, bottom - 9, self.CYAN)
        self._line(table, left, top, self.width // 2, top - 4, self.MAGENTA)
        self._line(table, self.width // 2, top - 4, right, top, self.MAGENTA)

        # Shooter lane and launch arrow.
        lane = max(left + 3, right - 3)
        self._line(table, lane, top + 8, lane, bottom - 2, (50, 120, 190))
        self._line(table, lane + 1, top + 8, right, top + 14, self.CYAN)
        self._line(table, lane - 1, bottom - 11, lane - 1, bottom - 6, self.YELLOW)
        self._line(table, lane - 2, bottom - 8, lane - 1, bottom - 11, self.YELLOW)
        self._line(table, lane, bottom - 8, lane - 1, bottom - 11, self.YELLOW)

        # Ramps make the silhouette recognizable even on 16 columns.
        self._line(table, left + 2, top + 23, self.width // 2 - 2, top + 12, (70, 170, 255))
        self._line(table, self.width // 2 - 2, top + 12, right - 3, top + 27, (70, 170, 255))
        self._line(table, left + 3, top + 54, self.width // 2, top + 42, self.MAGENTA)
        self._line(table, self.width // 2, top + 42, right - 4, top + 55, self.MAGENTA)

        # Three pop bumpers with a hot center and cool metal rim.
        for index, (bx, by) in enumerate(self._bumper_positions()):
            self._circle(table, bx, by, self._bumper_radius() + 1, (30, 100, 150))
            self._circle(table, bx, by, self._bumper_radius(), (100, 10, 80), True)
            self._pixel(table, bx, by, (255, 80 + index * 50, 20))

        # Five drop targets / mode lamps.
        lamp_y = top + 68
        for index in range(5):
            x = 3 + int(index * max(1, (self.width - 7) / 4))
            self._pixel(table, x, lamp_y, (35, 55, 75))
            self._pixel(table, x, lamp_y + 1, (70, 20, 50))

        # Slingshots and drain guides.
        sling_y = bottom - 27
        self._line(table, left + 2, sling_y - 10, left + 7, sling_y, self.RED)
        self._line(table, left + 7, sling_y, left + 3, sling_y + 5, self.ORANGE)
        self._line(table, right - 3, sling_y - 10, right - 8, sling_y, self.RED)
        self._line(table, right - 8, sling_y, right - 4, sling_y + 5, self.ORANGE)
        self._line(table, left, bottom - 9, self.width // 2 - 3, bottom - 1, (80, 140, 180))
        self._line(table, right, bottom - 9, self.width // 2 + 3, bottom - 1, (80, 140, 180))

    def _bumper_positions(self) -> List[Tuple[int, int]]:
        top = max(12, min(18, self.height // 7))
        return [
            (max(4, self.width // 3), top + 31),
            (min(self.width - 5, (self.width * 2) // 3), top + 31),
            (self.width // 2, top + 46),
        ]

    def _bumper_radius(self) -> int:
        return 1 if self.width < 24 else 2

    def _nearest_globe_clearance_safe_point(self, x: float, y: float) -> Tuple[float, float]:
        """Use clearance only to choose a safe future launch position."""
        origin_x = min(self.width - 1, max(0, int(round(x))))
        origin_y = min(self.height - 1, max(0, int(round(y))))
        max_radius = max(self.width, self.height)
        for radius in range(max_radius + 1):
            candidates = []
            top, bottom = origin_y - radius, origin_y + radius
            left, right = origin_x - radius, origin_x + radius
            perimeter = []
            if 0 <= top < self.height:
                perimeter.extend((xx, top) for xx in range(max(0, left), min(self.width, right + 1)))
            if radius and 0 <= bottom < self.height:
                perimeter.extend((xx, bottom) for xx in range(max(0, left), min(self.width, right + 1)))
            for yy in range(max(0, top + 1), min(self.height, bottom)):
                if 0 <= left < self.width:
                    perimeter.append((left, yy))
                if radius and right != left and 0 <= right < self.width:
                    perimeter.append((right, yy))
            for xx, yy in perimeter:
                if 2 <= xx <= self.width - 3 and not self._globe_clearance[yy, xx]:
                    candidates.append((abs(yy - y) + abs(xx - x), yy, xx))
            if candidates:
                _, safe_y, safe_x = min(candidates)
                return float(safe_x), float(safe_y)
        return x, y

    def _swept_globe_contact(
        self, previous_x: float, previous_y: float, mask: np.ndarray
    ) -> Optional[Tuple[int, int]]:
        distance = math.hypot(self.ball_x - previous_x, self.ball_y - previous_y)
        steps = max(1, int(math.ceil(distance * 2.0)))
        for step in range(1, steps + 1):
            fraction = step / steps
            px = int(round(previous_x + (self.ball_x - previous_x) * fraction))
            py = int(round(previous_y + (self.ball_y - previous_y) * fraction))
            if 0 <= px < self.width and 0 <= py < self.height and mask[py, px]:
                return px, py
        return None

    def _collide_with_globe_cores(self, previous_x: float, previous_y: float) -> None:
        """Score a swept exact-core boundary once and reflect with bounded energy."""
        if self._globe_bumper_strength <= 0.0:
            return
        contact = self._swept_globe_contact(previous_x, previous_y, self._globe_cores)
        if contact is None:
            self._globe_contact_active = False
            return
        if self._globe_contact_active:
            return
        px, py = contact
        nx, ny = previous_x - px, previous_y - py
        length = math.hypot(nx, ny)
        if length <= 1e-6:
            speed = math.hypot(self.ball_vx, self.ball_vy) or 1.0
            nx, ny, length = -self.ball_vx / speed, -self.ball_vy / speed, 1.0
        nx, ny = nx / length, ny / length
        dot = self.ball_vx * nx + self.ball_vy * ny
        restitution = 0.70 + 0.50 * self._globe_bumper_strength
        if dot < 0.0:
            self.ball_vx -= (1.0 + restitution) * dot * nx
            self.ball_vy -= (1.0 + restitution) * dot * ny
        else:
            self.ball_vx, self.ball_vy = -self.ball_vx * restitution, -self.ball_vy * restitution
        speed = math.hypot(self.ball_vx, self.ball_vy)
        if speed > self.MAX_PRIMARY_SPEED:
            scale = self.MAX_PRIMARY_SPEED / speed
            self.ball_vx *= scale
            self.ball_vy *= scale
        self.ball_x, self.ball_y = previous_x, previous_y
        self._globe_contact_active = True
        self._globe_bumper_hits += 1
        self._award(2500, "", self.YELLOW)
        self.bursts.append(Burst(px, py, self.YELLOW, life=0.45))

    def generate_frame(self, time_elapsed: float, frame_count: int) -> Any:
        fps = max(24.0, min(120.0, float(self.params.get("render_fps", 100.0))))
        if (self.last_rendered_frame is not None and self.last_render_elapsed is not None
                and 0.0 <= time_elapsed - self.last_render_elapsed < (1.0 / fps) - 1e-9):
            return self.rendered_frame(self.last_rendered_frame, changed=False)

        if self.last_elapsed is None or time_elapsed < self.last_elapsed:
            dt = 0.0
        else:
            dt = min(0.05, time_elapsed - self.last_elapsed)
        self.last_elapsed = time_elapsed
        self.last_render_elapsed = time_elapsed
        self._update(dt * max(12.0, float(self.params.get("table_tick_hz", 40.5))) / 30.0)
        self._render()

        frame = self.next_frame_buffer(clear=False)
        # Canonical layout is strip-major; physical LEDs run bottom-to-top.
        frame.reshape(self.width, self.height, 3)[:] = self._canvas[::-1].transpose(1, 0, 2)
        self._apply_scene_palette(frame)
        self.last_rendered_frame = frame
        return self.rendered_frame(frame, changed=True)

    def _update(self, dt: float):
        if dt <= 0.0:
            return
        self._sim_time += dt
        self._drain_primary_interaction()
        self._event_cooldown = max(0.0, self._event_cooldown - dt)
        self._hit_flash = max(0.0, self._hit_flash - dt * 4.0)
        self._failure_flash = max(0.0, self._failure_flash - dt * 2.5)
        self._success_flash = max(0.0, self._success_flash - dt * 2.2)
        self._primary_flipper_flash = max(0.0, self._primary_flipper_flash - dt)
        self.display_score += (self.score - self.display_score) * min(1.0, dt * 12.0)

        for burst in self.bursts:
            burst.age += dt
        self.bursts[:] = [burst for burst in self.bursts if burst.age < burst.life]

        if self.mode != "READY":
            self.mode_time -= dt
            if self.mode_time <= 0.0:
                if self.mode in ("JACKPOT", "MULTI"):
                    self._success("NICE", 25000)
                self.mode = "READY"
                self.multiplier = 1
        elif self._sim_time >= self._next_mode_at:
            self._start_minigame()

        if self.drain_time > 0.0:
            self.drain_time -= dt
            if self.drain_time <= 0.0:
                self._launch_ball()
            return

        # Small, stable pinball simulation. The table is narrow, so velocities
        # are deliberately biased upward to keep action distributed vertically.
        gravity = 31.0
        previous_x, previous_y = self.ball_x, self.ball_y
        self.ball_vy += gravity * dt
        self.ball_x += self.ball_vx * dt
        self.ball_y += self.ball_vy * dt
        left, right = 2.0, self.width - 3.0
        table_top = max(10.0, self.height / 10.0)

        if self.ball_x < left:
            self.ball_x = left
            self.ball_vx = abs(self.ball_vx) * 0.92 + 2.0
            self._wall_spark()
        elif self.ball_x > right:
            self.ball_x = right
            self.ball_vx = -abs(self.ball_vx) * 0.92 - 2.0
            self._wall_spark()
        if self.ball_y < table_top:
            self.ball_y = table_top
            self.ball_vy = abs(self.ball_vy) + 8.0
            self._award(750, "750", self.CYAN)

        self._collide_with_globe_cores(previous_x, previous_y)

        radius = self._bumper_radius() + 1.2
        for bx, by in self._bumper_positions():
            dx, dy = self.ball_x - bx, self.ball_y - by
            distance2 = dx * dx + dy * dy
            if distance2 < radius * radius and self._event_cooldown <= 0.0:
                if distance2 <= 0.04:
                    speed = math.hypot(self.ball_vx, self.ball_vy) or 1.0
                    nx, ny = -self.ball_vx / speed, -self.ball_vy / speed
                else:
                    distance = math.sqrt(distance2)
                    nx, ny = dx / distance, dy / distance
                impulse = 42.0
                self.ball_x = bx + nx * radius
                self.ball_y = by + ny * radius
                self.ball_vx = nx * impulse + self.random.uniform(-8.0, 8.0)
                self.ball_vy = ny * impulse - 14.0
                self._event_cooldown = 0.08
                self._hit_bumper(bx, by)

        target_y = max(12, min(18, self.height // 7)) + 68
        if abs(self.ball_y - target_y) < 1.2 and self._event_cooldown <= 0.0:
            index = min(4, max(0, int((self.ball_x - 2) * 5 / max(1, self.width - 4))))
            if not self.lamps[index]:
                self.lamps[index] = True
                self._award(1500, "+1500", self.GREEN)
                if all(self.lamps):
                    self.lamps = [False] * 5
                    self._success("BANK", 15000)
            self.ball_vy = -abs(self.ball_vy) - 9.0
            self._event_cooldown = 0.09

        flipper_y = self.height - 16.0
        if self.ball_y >= flipper_y and self.ball_y < self.height - 5:
            # Autoplay flippers: a hard upward kick with aim jitter.
            self.ball_y = flipper_y
            self.ball_vy = -self.random.uniform(72.0, 96.0)
            target_x = self.random.uniform(4.0, max(5.0, self.width - 5.0))
            self.ball_vx = (target_x - self.ball_x) * 1.1
            self._award(100, "", self.YELLOW, streak=False)
            self.bursts.append(Burst(self.ball_x, self.ball_y, self.YELLOW, life=0.3))

        # A rare miss gives the failure animation real contrast.
        chaos = max(0.0, min(1.0, float(self.params.get("chaos", 0.72))))
        miss_line = self.height - 7.0
        if self.ball_y > miss_line or (self._sim_time > 2 and self.random.random() < dt * 0.025 * chaos):
            self._drain()

    def _award(self, points: int, label: str, color: Color, streak: bool = True):
        if streak:
            self.streak += 1
        gain = points * max(1, self.multiplier)
        self.score += gain
        self._hit_flash = 1.0

    def _hit_bumper(self, x: float, y: float):
        self._award(1000 + self.streak * 100, "+1000", self.ORANGE)
        self.bursts.append(Burst(x, y, self.random.choice((self.ORANGE, self.MAGENTA, self.CYAN))))
        if self.streak in (5, 10, 20):
            self.multiplier = min(5, self.multiplier + 1)
        if self.streak and self.streak % 12 == 0:
            self._success("STREAK", 10000)

    def _wall_spark(self):
        if self._event_cooldown <= 0.0:
            self._award(250, "+250", self.CYAN, streak=False)
            self.bursts.append(Burst(self.ball_x, self.ball_y, self.CYAN, life=0.25))
            self._event_cooldown = 0.05

    def _success(self, label: str, bonus: int):
        self.score += bonus * max(1, self.multiplier)
        self._success_flash = 1.0
        for x in range(3, self.width - 2, max(2, self.width // 8)):
            self.bursts.append(Burst(x, self.height * 0.5, self.random.choice((self.GREEN, self.YELLOW, self.CYAN))))

    def _drain(self):
        self.balls -= 1
        self.streak = 0
        self.multiplier = 1
        self._failure_flash = 1.0
        self.drain_time = 0.85
        self.bursts.append(Burst(self.ball_x, self.height - 7, self.RED, life=0.7))
        if self.balls <= 0:
            self.balls = 3
            self.score = max(95000, self.score // 2)

    def _launch_ball(self):
        self.ball_x = self.width - 4.0
        self.ball_y = self.height - 18.0
        if self._globe_bumper_strength > 0.0:
            self.ball_x, self.ball_y = self._nearest_globe_clearance_safe_point(
                self.ball_x, self.ball_y
            )
        self._globe_contact_active = False
        self.ball_vx = -self.random.uniform(4.0, 12.0)
        self.ball_vy = -self.random.uniform(82.0, 105.0)

    def _start_minigame(self):
        modes = ("JACKPOT", "MULTI", "SKILL")
        self.mode = modes[self.mode_count % len(modes)]
        self.mode_count += 1
        self.mode_time = 3.5
        self.multiplier = min(5, 2 + self.mode_count % 3)
        self._success_flash = 1.0
        self._next_mode_at = self._sim_time + self.random.uniform(7.0, 11.0)

    def _render(self):
        canvas = self._canvas
        np.copyto(canvas, self._static)
        phase = self._sim_time

        # A dark rainbow interference field moves underneath the table art.
        # Palette lookup is much cheaper than per-pixel HSV/trigonometry at 100 Hz.
        np.maximum(canvas, self._background_field.render(phase), out=canvas)

        # Animated border chase lights, exactly on the physical outer columns.
        chase = int(phase * 18.0)
        for y in range(8, self.height - 8, 4):
            color = (self.CYAN, self.MAGENTA, self.YELLOW)[((y // 4) + chase) % 3]
            self._pixel(canvas, 0, y, color)
            self._pixel(canvas, self.width - 1, self.height - 1 - y, color)

        # A tiny spinner and satellite lamps fill the long center playfield with
        # continuous mechanical-looking motion without maintaining particles.
        spinner_y = int(self.height * 0.67)
        spinner_x = self.width // 2
        spinner_phase = int(phase * 14.0) % 8
        spinner_offsets = ((0, -3), (2, -2), (3, 0), (2, 2), (0, 3), (-2, 2), (-3, 0), (-2, -2))
        for offset in (0, 3, 6):
            dx, dy = spinner_offsets[(spinner_phase + offset) % 8]
            self._pixel(canvas, spinner_x + dx, spinner_y + dy,
                        (self.CYAN, self.YELLOW, self.MAGENTA)[offset // 3], True)
        self._line(canvas, spinner_x - 2, spinner_y, spinner_x + 2, spinner_y, (80, 120, 180))

        lamp_y = max(12, min(18, self.height // 7)) + 68
        for index, lit in enumerate(self.lamps):
            x = 3 + int(index * max(1, (self.width - 7) / 4))
            if lit or (self.mode != "READY" and (index + int(phase * 12)) % 3 == 0):
                color = self.GREEN if lit else self.MAGENTA
                self._soft_dot(canvas, x, lamp_y, color, 2.2)

        # Each bumper breathes with a different phase and hue, producing
        # gradients rather than flat on/off discs.
        bumper_colors = (self.ORANGE, self.MAGENTA, self.CYAN)
        for index, (bx, by) in enumerate(self._bumper_positions()):
            pulse = 0.5 + 0.5 * math.sin(phase * 8.0 + index * 2.1)
            color = tuple(int(channel * (0.35 + pulse * 0.65)) for channel in bumper_colors[index])
            self._soft_dot(canvas, bx, by, color, self._bumper_radius() + 2.2 + pulse)
            self._soft_dot(canvas, bx, by, self.WHITE, 0.8 + pulse * 0.4)

        # Flashing bumpers and concentric collision shockwaves.
        if self._hit_flash > 0.0:
            bx, by = min(self._bumper_positions(), key=lambda p: (p[0] - self.ball_x) ** 2 + (p[1] - self.ball_y) ** 2)
            self._circle(canvas, bx, by, self._bumper_radius() + int(self._hit_flash * 3), self.WHITE)
        for burst in self.bursts:
            progress = burst.age / max(0.01, burst.life)
            radius = 1 + int(progress * 7)
            fade = max(0.0, 1.0 - progress)
            color = tuple(int(channel * fade) for channel in burst.color)
            self._circle(canvas, int(burst.x), int(burst.y), radius, color)
            # Four deterministic sparks avoid particle objects and trig.
            spark = radius + 2
            self._pixel(canvas, int(burst.x) + spark, int(burst.y), color, True)
            self._pixel(canvas, int(burst.x) - spark, int(burst.y), color, True)
            self._pixel(canvas, int(burst.x), int(burst.y) + spark, color, True)
            self._pixel(canvas, int(burst.x), int(burst.y) - spark, color, True)

        # Flippers alternate rapidly with layered neon edges.
        flip = 1 if self._primary_flipper_flash > 0.0 else int(phase * 9.0) % 2
        fy = self.height - 16
        center = self.width // 2
        self._line(canvas, 4, fy + flip + 1, center - 2, fy - 2 + flip, self.MAGENTA)
        self._line(canvas, self.width - 5, fy + flip + 1, center + 2, fy - 2 + flip, self.CYAN)
        self._line(canvas, 4, fy + flip, center - 2, fy - 3 + flip, self.WHITE)
        self._line(canvas, self.width - 5, fy + flip, center + 2, fy - 3 + flip, self.WHITE)
        self._pixel(canvas, 4, fy + flip, self.RED)
        self._pixel(canvas, self.width - 5, fy + flip, self.RED)

        # Subpixel radial layers keep the fast ball fluid at 100 Hz while the
        # brilliant white core remains easy to follow on individual LEDs.
        if self.drain_time <= 0.0:
            for trail in range(5, 0, -1):
                fraction = trail / 5.0
                tx = self.ball_x - self.ball_vx * 0.010 * trail
                ty = self.ball_y - self.ball_vy * 0.010 * trail
                trail_color = (
                    int(35 * fraction),
                    int(90 * fraction),
                    int((180 + 60 * math.sin(phase * 12.0 + trail)) * fraction),
                )
                self._soft_dot(canvas, tx, ty, trail_color, 1.0 + fraction)
            self._soft_dot(canvas, self.ball_x, self.ball_y, self.CYAN, 2.7)
            self._soft_dot(canvas, self.ball_x, self.ball_y, self.WHITE, 1.35)

        # Full-table event signals are additive and intentionally brief.
        if self._success_flash > 0.0:
            value = int(90 * self._success_flash)
            np.maximum(canvas, np.array((0, value, value // 2), dtype=np.uint8), out=canvas)
        if self._failure_flash > 0.0 and int(phase * 16) % 2 == 0:
            value = int(110 * self._failure_flash)
            canvas[:, :, 0] = np.maximum(canvas[:, :, 0], value)

        # Minigames become a double-helix light show instead of text.
        if self.mode != "READY":
            colors = (self.MAGENTA, self.CYAN, self.YELLOW)
            for y in range(18, self.height - 22, 5):
                wave = math.sin(phase * 10.0 + y * 0.23)
                x = self.width * 0.5 + wave * self.width * 0.34
                color = colors[(y // 5 + self.mode_count) % len(colors)]
                self._soft_dot(canvas, x, y, color, 1.7)
                self._soft_dot(canvas, self.width - 1 - x, y, color, 1.2)

    def get_runtime_stats(self) -> Dict[str, Any]:
        return {
            "score": self.score,
            "display_score": int(self.display_score),
            "streak": self.streak,
            "multiplier": self.multiplier,
            "balls": self.balls,
            "minigame": self.mode,
            "active_effects": len(self.bursts),
            "globe_bumper_hits": self._globe_bumper_hits,
            "primary_interactions_received": self._primary_interactions_received,
            "primary_interactions_applied": self._primary_interactions_applied,
            "primary_interaction_pending": bool(self._primary_events),
        }
